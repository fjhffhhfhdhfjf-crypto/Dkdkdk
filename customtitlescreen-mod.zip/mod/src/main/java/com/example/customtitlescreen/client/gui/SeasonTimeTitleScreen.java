package com.example.customtitlescreen.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.CubeMapRenderer;
import net.minecraft.client.gui.screen.OptionsScreen;
import net.minecraft.client.gui.screen.RotatingCubeMapRenderer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Custom main-menu screen: procedural sky/ground background that reacts to a
 * selected Season + time-of-day, animated seasonal particles, and a small
 * control panel (top-right) with season tabs + a draggable time slider.
 *
 * NOTE ON VANILLA CLASS NAMES: MultiplayerScreen / SelectWorldScreen /
 * OptionsScreen constructor signatures occasionally change between minor
 * Minecraft versions. These match 1.21.x Mojang-mapped names; if your Yarn
 * build complains, check the equivalent class/constructor in your mappings
 * and adjust the four button actions in initButtons() below.
 */
public class SeasonTimeTitleScreen extends Screen {

    // Our OWN generated background textures — not Minecraft's built-in
    // panorama. Four separate cubemaps, one per season, under this mod's own
    // resource namespace (assets/customtitlescreen/textures/...), each truly
    // different (not a color filter over the same picture).
    private static RotatingCubeMapRenderer panoramaFor(String key) {
        return new RotatingCubeMapRenderer(
                new CubeMapRenderer(Identifier.of("customtitlescreen", "textures/gui/title/background/" + key))
        );
    }

    private static final java.util.Map<Season, RotatingCubeMapRenderer> PANORAMAS = new java.util.EnumMap<>(Season.class);
    static {
        PANORAMAS.put(Season.SPRING, panoramaFor("spring"));
        PANORAMAS.put(Season.SUMMER, panoramaFor("summer"));
        PANORAMAS.put(Season.AUTUMN, panoramaFor("autumn"));
        PANORAMAS.put(Season.WINTER, panoramaFor("winter"));
    }

    public enum Season {
        SPRING("ВЕСНА", 0x9BE15D, 0x6FB7E8),
        SUMMER("ЛЕТО", 0x4CAF50, 0x4FA8E0),
        AUTUMN("ОСЕНЬ", 0xD98A2B, 0x6E86A0),
        WINTER("ЗИМА", 0xE8F0FF, 0x7C93B5);

        final String label;
        final int groundColor;
        final int skyAccent;

        Season(String label, int groundColor, int skyAccent) {
            this.label = label;
            this.groundColor = groundColor;
            this.skyAccent = skyAccent;
        }
    }

    private static final String TITLE = "Fabric 1.21.4 — сезонное меню";
    private static final String SUBTITLE = "Сборка собрана и прогрета.";

    // top-right panel geometry
    private static final int PANEL_W = 190;
    private static final int PANEL_H = 92;
    private int panelX, panelY;
    private static final int SLIDER_H = 14;

    private Season currentSeason = Season.AUTUMN;
    private Season transitionFrom = null; // non-null while an animated transition is playing
    private float transitionT = 1f;       // 0..1 progress of that transition
    private static final float TRANSITION_SECONDS = 2.4f;

    private float timeHours = 20.5f; // 0-24, the real selected time (slider truth)
    private boolean draggingSlider = false;
    private double animClock = 0; // free-running seconds, drives sway/twinkle

    private final List<Particle> particles = new ArrayList<>();
    private final List<GrassBlade> grassBlades = new ArrayList<>();
    private final Random random = new Random();
    private final Random starSeed = new Random(12345L); // fixed seed: stars don't jump around each frame
    private long lastTickNanos = -1;

    private final List<ButtonWidget> seasonTabs = new ArrayList<>();

    protected SeasonTimeTitleScreen() {
        super(Text.literal("Custom Title Screen"));
    }

    @Override
    protected void init() {
        this.panelX = this.width - PANEL_W - 12;
        this.panelY = 10;

        spawnParticles();
        spawnGrass();
        initSeasonTabs();
        initMenuButtons();
    }

    // ---------------------------------------------------------- UI setup

    private void initSeasonTabs() {
        seasonTabs.clear();
        Season[] seasons = Season.values();
        int tabW = PANEL_W / seasons.length;
        for (int i = 0; i < seasons.length; i++) {
            Season s = seasons[i];
            ButtonWidget tab = ButtonWidget.builder(seasonTabLabel(s), btn -> {
                startSeasonTransition(s);
                refreshSeasonTabLabels();
            }).dimensions(panelX + i * tabW, panelY, tabW, 16).build();
            seasonTabs.add(tab);
            addDrawableChild(tab);
        }
    }

    private void refreshSeasonTabLabels() {
        Season[] seasons = Season.values();
        for (int i = 0; i < seasons.length; i++) {
            seasonTabs.get(i).setMessage(seasonTabLabel(seasons[i]));
        }
    }

    private Text seasonTabLabel(Season s) {
        return Text.literal(s == currentSeason ? "[" + s.label + "]" : s.label);
    }

    // ---------------------------------------------------------- season transition

    private void startSeasonTransition(Season target) {
        if (target == currentSeason && transitionFrom == null) return;
        transitionFrom = currentSeason;
        currentSeason = target;
        transitionT = 0f;
        if (target == Season.WINTER) {
            burstSnow();
        }
    }

    private void tickTransition(float deltaSeconds) {
        if (transitionFrom == null) return;
        transitionT += deltaSeconds / TRANSITION_SECONDS;
        if (transitionT >= 1f) {
            transitionT = 1f;
            transitionFrom = null; // done — settle particle count back to normal for the new season
            trimParticlesToTarget();
        }
    }

    private float easeInOut(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    /** Extra flakes added immediately so snow visibly starts falling right as the transition begins. */
    private void burstSnow() {
        for (int i = 0; i < 55; i++) {
            float x = random.nextFloat() * Math.max(this.width, 1);
            float y = -random.nextFloat() * this.height * 0.6f;
            float speed = 8f + random.nextFloat() * 18f;
            float size = 1.5f + random.nextFloat() * 2.2f;
            float drift = (random.nextFloat() - 0.5f) * 5f;
            particles.add(new Particle(x, y, speed, size, drift, 0xFFFFFFFF));
        }
    }

    /** After a transition settles, trim/replenish the particle field to the destination season's normal count. */
    private void trimParticlesToTarget() {
        int target = particleCountFor(currentSeason);
        while (particles.size() > target) {
            particles.remove(particles.size() - 1);
        }
        while (particles.size() < target) {
            particles.add(randomParticle(random.nextInt(Math.max(this.height, 200))));
        }
    }

    private int particleCountFor(Season s) {
        return switch (s) {
            case WINTER -> 90;
            case AUTUMN -> 70;
            case SPRING -> 60;
            case SUMMER -> 30;
        };
    }

    private void initMenuButtons() {
        int buttonW = 150;
        int x = 16;
        int y = this.height / 2 - 10;
        int spacing = 22;

        addDrawableChild(ButtonWidget.builder(Text.literal("Сетевая игра"), btn -> {
            if (this.client != null) this.client.setScreen(new MultiplayerScreen(this));
        }).dimensions(x, y, buttonW, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Одиночная игра"), btn -> {
            if (this.client != null) this.client.setScreen(new SelectWorldScreen(this));
        }).dimensions(x, y + spacing, buttonW, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Сменить аккаунт"), btn -> {
            if (this.client != null) this.client.setScreen(new AccountSwitchScreen(this));
        }).dimensions(x, y + spacing * 2, buttonW, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Настройки"), btn -> {
            if (this.client != null) this.client.setScreen(new OptionsScreen(this, this.client.options));
        }).dimensions(x, y + spacing * 3 + 6, buttonW / 2 - 3, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Выйти из игры"), btn -> {
            if (this.client != null) this.client.scheduleStop();
        }).dimensions(x + buttonW / 2 + 3, y + spacing * 3 + 6, buttonW / 2 - 3, 20).build());
    }

    // ---------------------------------------------------------- particles

    private void spawnParticles() {
        particles.clear();
        int count = particleCountFor(currentSeason);
        for (int i = 0; i < count; i++) {
            particles.add(randomParticle(random.nextInt(Math.max(this.height, 200))));
        }
    }

    private void spawnGrass() {
        grassBlades.clear();
        int count = this.width / 14;
        for (int i = 0; i < count; i++) {
            float x = random.nextFloat() * Math.max(this.width, 1);
            float growSeconds = 2.5f + random.nextFloat() * 3.5f;
            float startProgress = random.nextFloat(); // so blades aren't all synced
            grassBlades.add(new GrassBlade(x, growSeconds, startProgress * growSeconds));
        }
    }

    private void tickGrass(float deltaSeconds) {
        for (GrassBlade b : grassBlades) {
            b.age += deltaSeconds;
            if (b.age > b.growSeconds * 1.6f) {
                b.age = 0f; // cut back down and re-grow, endless gentle cycle
            }
        }
    }

    private float bladeHeight(GrassBlade b) {
        float maxH = 10f;
        if (b.age <= b.growSeconds) {
            return maxH * (b.age / b.growSeconds); // growing
        }
        return maxH; // fully grown, holds until reset
    }

    private Particle randomParticle(int startY) {
        float x = random.nextFloat() * (this.width == 0 ? 1000 : this.width);
        float speed = 10f + random.nextFloat() * 20f;
        float size = 1.5f + random.nextFloat() * 2.0f;
        float drift = (random.nextFloat() - 0.5f) * 6f;
        return new Particle(x, startY, speed, size, drift, particleColorFor(currentSeason));
    }

    private void tickParticles(float deltaSeconds) {
        for (int i = 0; i < particles.size(); i++) {
            Particle p = particles.get(i);
            p.y += p.speed * deltaSeconds;
            p.x += p.drift * deltaSeconds;
            if (p.y > this.height) {
                // respawn using whatever season is CURRENT right now, so a field
                // of old-season particles gradually repopulates with the new
                // season's look as they naturally cycle off the bottom.
                particles.set(i, randomParticle(-4));
            }
        }
    }

    private int particleColorFor(Season s) {
        return switch (s) {
            case WINTER -> 0xFFFFFFFF; // snow
            case AUTUMN -> 0xFFD98A2B; // falling leaves
            case SPRING -> 0xFFF7C6DE; // petals
            case SUMMER -> 0xFFFFF6B0; // pollen/dust
        };
    }

    // ---------------------------------------------------------- time helpers

    /** The real, user-selected time (what the slider/clock always show). */
    private String timeLabel() { return timeLabel(timeHours); }
    private boolean isDaytime() { return isDaytime(timeHours); }
    private float dayFactor() { return dayFactor(timeHours); }

    /** During a season transition the SKY visually fast-forwards through a
     *  couple of day/night cycles (a "time-lapse" sweep) while the real
     *  selected time on the slider/clock stays untouched underneath. */
    private float displayTime() {
        if (transitionFrom == null) return timeHours;
        float t = easeInOut(transitionT);
        return (timeHours + t * 48f + 24f) % 24f;
    }

    private String timeLabel(float hours) {
        int h = ((int) hours) % 24;
        if (h >= 5 && h < 11) return "Утро";
        if (h >= 11 && h < 17) return "День";
        if (h >= 17 && h < 21) return "Вечер";
        return "Ночь";
    }

    private boolean isDaytime(float hours) {
        int h = ((int) hours) % 24;
        return h >= 6 && h < 18;
    }

    /** 0 = full night, 1 = full day, smooth around dawn/dusk */
    private float dayFactor(float hours) {
        float h = hours % 24f;
        float dawn = smooth(h, 4f, 7f);
        float dusk = 1f - smooth(h, 18f, 21f);
        return Math.max(0f, Math.min(dawn, dusk));
    }

    private float smooth(float h, float start, float end) {
        if (h <= start) return 0f;
        if (h >= end) return 1f;
        return (h - start) / (end - start);
    }

    private int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------------------------------------------------------- render

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float deltaSeconds = lastTickNanos < 0 ? 0f : (now - lastTickNanos) / 1_000_000_000f;
        deltaSeconds = Math.min(deltaSeconds, 0.25f); // clamp huge jumps (e.g. after a lag spike)
        lastTickNanos = now;
        animClock += deltaSeconds;
        tickParticles(deltaSeconds);
        tickGrass(deltaSeconds);
        tickTransition(deltaSeconds);

        // 1) background — a real animated cross-dissolve between the two
        // cubemaps while a transition is playing, using the same alpha
        // parameter vanilla uses for its own fade-in (so this is a supported,
        // not hacked-in, use of the renderer).
        if (transitionFrom != null) {
            float t = easeInOut(transitionT);
            PANORAMAS.get(transitionFrom).render(context, this.width, this.height, 1f - t, delta);
            PANORAMAS.get(currentSeason).render(context, this.width, this.height, t, delta);
        } else {
            PANORAMAS.get(currentSeason).render(context, this.width, this.height, 1f, delta);
        }

        // IMPORTANT: the panorama render call changes GL depth/blend state for
        // its 3D draw. Every 2D draw below MUST run after this reset, or it can
        // silently fail the depth test and never appear.
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // 2) sky elements — driven by displayTime() so the sun/moon and
        // day-night wash visibly sweep through fast during a transition
        float skyTime = displayTime();
        drawCelestialBody(context, skyTime);
        drawStars(context, skyTime);
        drawSeasonWash(context, skyTime);

        // 3) ground-level seasonal effects + falling particles — cross-faded
        // the same way as the background while transitioning
        if (transitionFrom != null) {
            float t = easeInOut(transitionT);
            drawSeasonGround(context, transitionFrom, 1f - t, skyTime);
            drawSeasonGround(context, currentSeason, t, skyTime);
        } else {
            drawSeasonGround(context, currentSeason, 1f, skyTime);
        }
        drawParticles(context);

        // 4) HUD text/panel — always shows the REAL selected time, never the sweep
        drawHeaderAndAccount(context);
        drawSeasonTimePanel(context, mouseX, mouseY);

        // 5) vanilla widgets (buttons) — Minecraft manages render state for these itself
        super.render(context, mouseX, mouseY, delta);

        // 6) title/footer text on top of everything
        drawTitleText(context);
        drawFooter(context);
    }

    // ---------------------------------------------------------- sky

    private void drawCelestialBody(DrawContext context, float atTime) {
        float t = atTime % 24f;
        boolean sun = isDaytime(atTime);
        float cycleStart = sun ? 6f : 18f;
        float cycleLength = 12f;
        float progress = ((t - cycleStart + 24f) % 24f) / cycleLength;
        progress = Math.max(0f, Math.min(1f, progress));

        int cx = (int) (this.width * progress);
        int arcHeight = this.height / 3;
        int cy = (int) (this.height * 0.32f - Math.sin(progress * Math.PI) * arcHeight * 0.6);

        if (sun) {
            drawGlowDisc(context, cx, cy, 16, 0xFFFFE9A8, 0x33FFD24C);
        } else {
            drawGlowDisc(context, cx, cy, 12, 0xFFE8EEFF, 0x22AFC0FF);
        }
    }

    private void drawGlowDisc(DrawContext context, int cx, int cy, int radius, int coreColor, int glowColor) {
        // soft outer glow, several oversized translucent rings
        for (int r = radius * 2; r > radius; r -= 2) {
            drawDisc(context, cx, cy, r, glowColor);
        }
        drawDisc(context, cx, cy, radius, coreColor);
    }

    private void drawDisc(DrawContext context, int cx, int cy, int radius, int color) {
        for (int dy = -radius; dy <= radius; dy++) {
            int span = (int) Math.sqrt(Math.max(0, radius * radius - dy * dy));
            if (span <= 0) continue;
            context.fill(cx - span, cy + dy, cx + span, cy + dy + 1, color);
        }
    }

    private void drawStars(DrawContext context, float atTime) {
        float night = 1f - dayFactor(atTime);
        if (night <= 0.05f) return;
        int alpha = (int) (night * 200);
        starSeed.setSeed(12345L); // deterministic field every frame
        int count = 90;
        for (int i = 0; i < count; i++) {
            int x = starSeed.nextInt(Math.max(this.width, 1));
            int y = starSeed.nextInt(Math.max(this.height * 55 / 100, 1));
            boolean twinkle = ((x + y + (int) (animClock * 2.5)) % 7) == 0;
            int a = twinkle ? Math.min(255, alpha + 55) : alpha;
            context.fill(x, y, x + 1, y + 1, (a << 24) | 0x00FFFFFF);
        }
    }

    private void drawSeasonWash(DrawContext context, float atTime) {
        float day = dayFactor(atTime);
        int nightWash = 0x551B2A4A;
        int seasonWash = (currentSeason.skyAccent & 0x00FFFFFF) | 0x22000000;
        context.fill(0, 0, this.width, this.height, lerpColor(nightWash, seasonWash, day));
    }

    // ---------------------------------------------------------- ground

    private void drawSeasonGround(DrawContext context, Season season, float alphaMul, float atTime) {
        if (alphaMul <= 0.01f) return;
        int groundH = Math.max(36, this.height / 12);
        int groundTop = this.height - groundH;
        float day = dayFactor(atTime);

        switch (season) {
            case WINTER -> {
                int snow = withAlpha(lerpColor(0xFFCCE0FF, 0xFFFFFFFF, day), (int) (255 * alphaMul));
                context.fillGradient(0, groundTop, this.width, this.height, 0x00FFFFFF, snow);
                for (int i = 0; i < (int) (40 * alphaMul); i++) {
                    int x = (int) (random.nextFloat() * this.width);
                    int y = groundTop + (int) (random.nextFloat() * groundH);
                    context.fill(x, y, x + 1, y + 1, withAlpha(0xFFFFFFFF, (int) (0xAA * alphaMul)));
                }
            }
            case AUTUMN -> {
                int leaf = withAlpha(lerpColor(0xFF6B4A20, season.groundColor | 0xFF000000, day), (int) (0x66 * alphaMul));
                context.fillGradient(0, groundTop, this.width, this.height, 0x00000000, leaf);
            }
            case SUMMER -> {
                int warm = withAlpha(lerpColor(0xFF2E4D22, 0xFF6FAE3C, day), (int) (0x55 * alphaMul));
                context.fillGradient(0, groundTop, this.width, this.height, 0x00000000, warm);
            }
            case SPRING -> {
                int green = withAlpha(lerpColor(0xFF25361C, 0xFF8FD65A, day), (int) (0x55 * alphaMul));
                context.fillGradient(0, groundTop, this.width, this.height, 0x00000000, green);
                drawGrowingGrass(context, groundTop + groundH - 2, alphaMul);
            }
        }
    }

    private int withAlpha(int argb, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24) | (argb & 0x00FFFFFF);
    }

    private void drawGrowingGrass(DrawContext context, int baselineY, float alphaMul) {
        for (GrassBlade b : grassBlades) {
            float h = bladeHeight(b);
            float sway = (float) Math.sin(animClock * 1.6 + b.x * 0.08f) * 1.6f;
            int xTop = (int) (b.x + sway);
            int xBase = (int) b.x;
            context.fill(xBase, baselineY, xBase + 2, baselineY + 1, withAlpha(0xFF4CAF50, (int) (255 * alphaMul)));
            context.fill(xTop, baselineY - (int) h, xTop + 2, baselineY - (int) h + 2, withAlpha(0xFF6FCB6C, (int) (255 * alphaMul)));
            context.fill(xBase, baselineY - (int) h, xTop + 2, baselineY, withAlpha(0xFF4CAF50, (int) (200 * alphaMul)));
        }
    }

    private void drawParticles(DrawContext context) {
        for (Particle p : particles) {
            int s = Math.max(1, Math.round(p.size));
            context.fill((int) p.x, (int) p.y, (int) p.x + s, (int) p.y + s, p.color);
        }
    }

    private void drawHeaderAndAccount(DrawContext context) {
        String name = this.client != null ? this.client.getSession().getUsername() : "Player";
        context.drawTextWithShadow(this.textRenderer, Text.literal(name), 14, 12, 0xFFFFFF);
    }

    private void drawTitleText(DrawContext context) {
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(TITLE), this.width / 2, 16, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer, Text.literal(SUBTITLE), 14, this.height / 2 - 34, 0xC8C8C8);
    }

    private void drawFooter(DrawContext context) {
        context.drawTextWithShadow(this.textRenderer, Text.literal("CustomTitleScreen 1.0.0  ·  Minecraft 1.21.4"), 6, this.height - 12, 0x808080);
    }

    private void drawSeasonTimePanel(DrawContext context, int mouseX, int mouseY) {
        // panel backdrop — bright border so it can never blend invisibly
        // into the background regardless of scene brightness.
        context.fill(panelX - 2, panelY - 2, panelX + PANEL_W + 2, panelY + PANEL_H + 2, 0xFFFFFFFF);
        context.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, 0xE6101014);

        int clockY = panelY + 22;
        context.drawTextWithShadow(this.textRenderer,
                Text.literal(String.format("%02d:%02d  %s", (int) timeHours % 24, (int) ((timeHours % 1) * 60), timeLabel())),
                panelX + 8, clockY, 0xFFFFFF);

        // sun/moon indicator, bigger and glowing to match the sky icon
        int iconCx = panelX + PANEL_W - 14, iconCy = clockY + 4;
        if (isDaytime(timeHours)) {
            drawDisc(context, iconCx, iconCy, 6, 0xFFFFE9A8);
        } else {
            drawDisc(context, iconCx, iconCy, 5, 0xFFE8EEFF);
        }

        drawTimeSlider(context, panelY + PANEL_H - SLIDER_H - 10);
    }

    private int sliderTrackX() {
        return panelX + 6;
    }

    private int sliderTrackW() {
        return PANEL_W - 12;
    }

    private void drawTimeSlider(DrawContext context, int trackY) {
        int trackX = sliderTrackX();
        int trackW = sliderTrackW();

        // gradient stops across the 24h cycle: night -> dawn -> day -> dusk -> night
        int night = 0xFF1B2A4A, dawn = 0xFFF2A65A, day = 0xFF7EC8F2, dusk = 0xFFDA6A45;
        for (int px = 0; px < trackW; px++) {
            float h = (px / (float) trackW) * 24f;
            int color;
            if (h < 5) color = night;
            else if (h < 7) color = lerpColor(night, dawn, (h - 5) / 2f);
            else if (h < 11) color = lerpColor(dawn, day, (h - 7) / 4f);
            else if (h < 17) color = day;
            else if (h < 19) color = lerpColor(day, dusk, (h - 17) / 2f);
            else if (h < 21) color = lerpColor(dusk, night, (h - 19) / 2f);
            else color = night;
            context.fill(trackX + px, trackY, trackX + px + 1, trackY + SLIDER_H, color);
        }

        // handle
        int handleX = trackX + (int) ((timeHours / 24f) * trackW);
        context.fill(handleX - 2, trackY - 2, handleX + 3, trackY + SLIDER_H + 2, 0xFFFFFFFF);
    }

    // ---------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isOverSlider(mouseX, mouseY)) {
            draggingSlider = true;
            updateSliderFromMouse(mouseX);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSlider) {
            updateSliderFromMouse(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingSlider = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private boolean isOverSlider(double mouseX, double mouseY) {
        int trackY = panelY + PANEL_H - SLIDER_H - 10;
        return mouseX >= sliderTrackX() - 4 && mouseX <= sliderTrackX() + sliderTrackW() + 4
                && mouseY >= trackY - 6 && mouseY <= trackY + SLIDER_H + 6;
    }

    private void updateSliderFromMouse(double mouseX) {
        float t = (float) ((mouseX - sliderTrackX()) / (double) sliderTrackW());
        timeHours = Math.max(0f, Math.min(24f, t * 24f));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class Particle {
        float x, y, speed, size, drift;
        int color;
        Particle(float x, float y, float speed, float size, float drift, int color) {
            this.x = x;
            this.y = y;
            this.speed = speed;
            this.size = size;
            this.drift = drift;
            this.color = color;
        }
    }

    private static class GrassBlade {
        final float x;
        final float growSeconds;
        float age;
        GrassBlade(float x, float growSeconds, float age) {
            this.x = x;
            this.growSeconds = growSeconds;
            this.age = age;
        }
    }
}
