package com.example.customtitlescreen.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * MinecraftClient stores the active login session in a private final field.
 * This accessor lets us overwrite it after a successful Microsoft login so
 * the switch takes effect without restarting the game.
 *
 * NOTE: the field is named "session" as of 1.21.x Yarn mappings. If your
 * build fails on this file, open MinecraftClient in your IDE/mappings
 * browser, find the Session field, and update the name in @Accessor below.
 * Also double check the package for Session — some mapping sets have it
 * under net.minecraft.client.util instead of net.minecraft.client.session.
 */
@Mixin(MinecraftClient.class)
public interface MinecraftClientSessionAccessor {

    @Accessor("session")
    void customtitlescreen$setSession(Session session);

    @Accessor("session")
    Session customtitlescreen$getSession();
}
